//
//  AddEditNotesViewController.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import UIKit
import CoreData
class AddEditNotesViewController: UIViewController,StoryboardInstantiable {

    //MARK: - Outlets
    @IBOutlet weak var titleTextField : UITextField!
    @IBOutlet weak var descriptTextView : UITextView!
    @IBOutlet weak var dateLable : UILabel!
    @IBOutlet weak var dateTextField : UITextField!
    
    //MARK: - Properties
     var viewModel: NotesEditViewModel!
    
    //MARK: - Function to create viewController
    static func create(with viewModel: NotesEditViewModel, storyBoardName: String) -> AddEditNotesViewController{
        let vc = AddEditNotesViewController.instantiateViewController(storyBoardName: storyBoardName)
        vc.viewModel = viewModel
        return vc
    }
    
    //MARK: - ViewContrller Life Cycles
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBar()
        setupDatePicker()
        updateUIConfigure()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
       
    }
    
    private func updateUIConfigure(){
        if self.viewModel.isComesFromEdit.value {
            self.viewModel.fetchNotesDetails(id: self.viewModel.notesID.value) { title, subtitle, date in
                DispatchQueue.main.async {
                    self.titleTextField.text = title
                    self.descriptTextView.text = subtitle
                    self.dateLable.text = date
                }
            }
        }
    }
    
    func setupNavBar(){
        let backBarButton = UIBarButtonItem.init(image: UIImage.init(named: "back_arrow"), style: .plain, target: self, action: #selector(backClicked(_:)))
        let saveButton = UIBarButtonItem.init(image: UIImage.init(named: "save"), style: .plain, target: self, action: #selector(saveClicked(_:)))
        let deleteButton = UIBarButtonItem.init(image: UIImage.init(named: "delete"), style: .plain, target: self, action: #selector(deleteClicked(_:)))
        self.setupNavigationItem(with: "Notepad", mainTitle: "", backItem: backBarButton, rightitems: [deleteButton,saveButton])
    }
    
    
    func setupDatePicker(){
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        dateLable.text = formatter.string(from: date)
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.minimumDate = date
        datePicker.preferredDatePickerStyle = .inline
        datePicker.addTarget(self, action: #selector(datePickerValueChanged), for: .valueChanged)
        datePicker.frame.size = CGSize(width: 0, height: 250)
        datePicker.contentMode = .center
        dateTextField.inputView = datePicker
    }
    
    @objc func datePickerValueChanged(sender:UIDatePicker){
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        dateLable.text = formatter.string(from: sender.date)
        self.view.endEditing(true)
    }
    
    @objc func backClicked(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func deleteClicked(_ sender: UIButton){
        self.viewModel.deleteSingleObjectFromNotes(id: self.viewModel.notesID.value)
        self.navigationController?.popViewController(animated: true)
    }
    
   
    
    @objc func saveClicked(_ sender: UIButton){
        if self.viewModel.isComesFromEdit.value{
            self.viewModel.updateNotesData(title: titleTextField.text!, subtitle: descriptTextView.text!, date: dateLable.text!)
            self.navigationController?.popViewController(animated: true)
        }else{
            let noteId = randomString(length: 6)
            self.viewModel.saveNotesDetails(notesData: NotesData(title: titleTextField.text!, subtitle: descriptTextView.text, date: dateLable.text!, id: noteId))
            self.navigationController?.popViewController(animated: true)
        }
        self.navigationController?.popViewController(animated: true)
    }
}

extension AddEditNotesViewController{
    
    //Create ramdom numbers for saving id into coredata
    
    func randomString(length: Int) -> String {
      let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      return String((0..<length).map{ _ in letters.randomElement()! })
    }
}
