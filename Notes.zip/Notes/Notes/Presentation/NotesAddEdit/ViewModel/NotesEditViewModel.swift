//
//  NotesEditViewModel.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation
import CoreData

struct NotesEditViewModelActions{
 
}

protocol NotesEditViewModelInput{
    func fetchNotesDetails(id:String,completion: (String,String,String) -> Void)
    func deleteSingleObjectFromNotes(id:String)
    func updateNotesData(title:String,subtitle:String,date:String)
    func saveNotesDetails(notesData: NotesData)
}

protocol NotesEditViewModelOutput{
    var isComesFromEdit: Observable<Bool> {get}
    var notesID: Observable<String> {get}
}

protocol NotesEditViewModel : NotesEditViewModelInput, NotesEditViewModelOutput{
    
}

    
class DefaultNotesEditViewModel : NotesEditViewModel{
 
    var notesID: Observable<String> = Observable("")
    var isComesFromEdit: Observable<Bool> = Observable(false)
    
    private let actions: NotesEditViewModelActions?
    
    init(actions: NotesEditViewModelActions? = nil){
        self.actions = actions
    }
    
}

extension DefaultNotesEditViewModel{
    
    //Fetch Notes details from coredata
    
    func fetchNotesDetails(id: String, completion: (String, String, String) -> Void) {
        let request: NSFetchRequest<Notes> = Notes.fetchRequest()
        let managedObjectContext = CoreDataStack.shared.moc
        let predicate = NSPredicate(format: "id == %@",id )
        request.predicate = predicate
        do {
            let notes = try managedObjectContext.fetch(request)
            completion(notes[0].title ?? "",notes[0].subtitle ?? "",notes[0].date ?? "")
        }
        catch {
            fatalError("Error getting student count")
        }
        
    }
   
    func deleteSingleObjectFromNotes(id:String) {
        let managedObjectContext = CoreDataStack.shared.moc
        let entity = NSEntityDescription.entity(forEntityName: "Notes", in: managedObjectContext)
        let request = NSFetchRequest<NSFetchRequestResult>()
        request.entity = entity
        let predicate = NSPredicate(format: "id == %@",id)
        request.predicate = predicate
        if let result = try? managedObjectContext.fetch(request) {
            for object in result {
                managedObjectContext.delete(object as! NSManagedObject)
            }
        }
        do {
            CoreDataStack.shared.saveContext()
        }catch {
            fatalError("Error")
        }
    }
    
    //Update Notes details into coredata
     func updateNotesData(title:String,subtitle:String,date:String){
         let contact = checkDataStore(id: self.notesID.value)
        contact[0].title = title
        contact[0].subtitle = subtitle
        contact[0].date = date
        CoreDataStack.shared.saveContext()
    }
    
    func checkDataStore(id:String) -> [Notes] {
        let request: NSFetchRequest<Notes> = Notes.fetchRequest()
        let managedObjectContext = CoreDataStack.shared.moc
        let predicate = NSPredicate(format: "id == %@",id )
        request.predicate = predicate
        do {
            let notes = try managedObjectContext.fetch(request)
           return notes
        }
        catch {
            fatalError("Error")
        }
    }
    
    //Save Notes details into coredata
    internal func saveNotesDetails(notesData: NotesData) {
        let coreData = CoreDataStack.shared
        let managedObjectContext = coreData.moc
        let contact = Notes(context: managedObjectContext)
        contact.date = notesData.date
        contact.title = notesData.title
        contact.subtitle = notesData.subtitle
        contact.id = notesData.id
        coreData.saveContext()
    }
    
}
