//
//  NotesTableViewCell.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import UIKit

class NotesTableViewCell: UITableViewCell {

    //MARK: - Outlets
    @IBOutlet weak var titleLable : UILabel!
    @IBOutlet weak var subtitleLable : UILabel!
    @IBOutlet weak var dateLable : UILabel!
    @IBOutlet weak var editImage : UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
