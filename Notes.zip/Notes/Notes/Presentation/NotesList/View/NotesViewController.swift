//
//  NotesViewController.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import UIKit
import CoreData
class NotesViewController: UIViewController,StoryboardInstantiable {
    
    //MARK: - Outlets
    @IBOutlet weak var tableView : UITableView!
    @IBOutlet weak var addView : UIView!

    //MARK: - Properties
   
    var notesServices: NotesServices?
    var viewModel: NotesViewModel!
    
    //MARK: - Function to create viewController
    static func create(with viewModel: NotesViewModel, storyBoardName: String) -> NotesViewController{
        let vc = NotesViewController.instantiateViewController(storyBoardName: storyBoardName)
        vc.viewModel = viewModel
        return vc
    }
    
    //MARK: - ViewController Life Cycles
    override func viewDidLoad() {
        super.viewDidLoad()
        self.bind(to: self.viewModel)
        registerCells()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        self.viewModel.getUserNotesDataDetails()
    }
    
    private func registerCells(){
        self.addView.layer.cornerRadius = self.addView.frame.size.height/2
        self.addView.layer.masksToBounds = true
        tableView.register(UINib(nibName: "NotesTableViewCell", bundle: nil), forCellReuseIdentifier: "NotesTableViewCell")
    }
    //MARK: - Bind observers
    
    private func bind(to viewModel: NotesViewModel){
        viewModel.notesData.observe(on: self) { [weak self] in
            self?.showNotes($0)
        }
        
    }
   
    private func showNotes(_ data: [Notes]){
        self.tableView.reloadData()
    }
    
    @IBAction func dateSortingAction(_ sender : UIButton){
        self.viewModel.notesData.value = self.viewModel.notesData.value.sorted(by: { $0.date! < $1.date! })
    }
    
    @IBAction func titleSortingAction(_ sender : UIButton){
        self.viewModel.notesData.value = self.viewModel.notesData.value.sorted(by: { $0.title! < $1.title! })
    }

    @IBAction func addNoteAction(_ sender : UIButton){
        self.viewModel.showNotesEditScreen(id: "", isComesFromEdit: false)
    }
}

extension NotesViewController : UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.notesData.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotesTableViewCell") as! NotesTableViewCell
        let data = self.viewModel.notesData.value[indexPath.row]
        cell.titleLable.text = data.title
        cell.subtitleLable.text = data.subtitle
        cell.dateLable.text = data.date
        cell.editImage.image = UIImage(named: "edit")
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.viewModel.showNotesEditScreen(id: self.viewModel.notesData.value[indexPath.row].id ?? "", isComesFromEdit: true)
    }
}
