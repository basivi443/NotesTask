//
//  NotesFlowCoordinator.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation

import UIKit

protocol NotesFlowCoordinatorDependencies{
    func makeNotesViewController(actions: NotesViewModelActions) -> NotesViewController
    func makeNotesEditViewController(actions : NotesEditViewModelActions) -> AddEditNotesViewController
}



 class NotesFlowCoordinator {
    private weak var navigationController: UINavigationController?
    private let dependencies: NotesFlowCoordinatorDependencies
    private var flowCoordinator: AppFlowCoordinator
     
    init(navigationController: UINavigationController,
         dependencies: NotesFlowCoordinatorDependencies, flowCoordinator: AppFlowCoordinator) {
        self.navigationController = navigationController
        self.dependencies = dependencies
        self.flowCoordinator = flowCoordinator
    }
    
    func start() {
        let actions = NotesViewModelActions(showNotesEditScreen: showNotesEditScreen)
        let vc = dependencies.makeNotesViewController(actions: actions)
        navigationController?.pushViewController(vc, animated: true)
    }
    
     func showNotesEditScreen(id:String,isComesFromEdit:Bool){
        let actions = NotesEditViewModelActions()
        let vc = dependencies.makeNotesEditViewController(actions: actions)
         vc.viewModel.isComesFromEdit.value = isComesFromEdit
         vc.viewModel.notesID.value = id
        navigationController?.pushViewController(vc, animated: true)
    }
    
}
