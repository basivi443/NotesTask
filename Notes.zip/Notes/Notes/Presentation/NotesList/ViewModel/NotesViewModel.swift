//
//  NotesViewModel.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation
import CoreData
struct NotesViewModelActions{
    let showNotesEditScreen : (String,Bool) -> Void
}

protocol NotesViewModelInput{
    func showNotesEditScreen(id:String,isComesFromEdit:Bool)
   func getUserNotesDataDetails()
}

protocol NotesViewModelOutput{
    var isComesFromEdit: Bool {get set}
    var notesData: Observable<[Notes]> {get}
    
}

protocol NotesViewModel : NotesViewModelInput,NotesViewModelOutput{
    
}

class DefaultNotesViewModel : NotesViewModel{
    
    
    var notesData: Observable<[Notes]> = Observable([])
    
    var isComesFromEdit: Bool = false
     let actions: NotesViewModelActions?
    
    init(actions: NotesViewModelActions? = nil){
        self.actions = actions
    }
    
  
   
     
     //Fetch the contacts from coredata
     func getUserNotesDataDetails(){
         let request: NSFetchRequest<Notes> = Notes.fetchRequest()
         let managedObjectContext = CoreDataStack.shared.moc
         do {
             let notes = try managedObjectContext.fetch(request)
             notesData.value = notes
         }
         catch {
             fatalError("Error getting of contacts")
         }
         
     }
     
}
extension DefaultNotesViewModel{
    
    func showNotesEditScreen(id: String, isComesFromEdit: Bool) {
        actions?.showNotesEditScreen(id,isComesFromEdit)
    }
}
