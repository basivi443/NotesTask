//
//  NotesDIContainer.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation

import UIKit

 class NotesDIContainer{


    // TODO: - Use Cases
    
    //TODO: - Repositories
    
    // MARK: - Flow Coordinators
    
    init() {
        
    }
    
    func makeNotesFlowCoordinator(navigationController: UINavigationController, flowCoordinator: AppFlowCoordinator) -> NotesFlowCoordinator{
        return NotesFlowCoordinator(navigationController: navigationController, dependencies: self, flowCoordinator: flowCoordinator)
    }
}

extension NotesDIContainer: SceneDIContainer{
    static var storyBoard: String {
        return "Main"
    }
}

extension NotesDIContainer: NotesFlowCoordinatorDependencies{
  
    
    
    //TODO: - Notes
    
    func makeNotesViewController(actions: NotesViewModelActions) -> NotesViewController {
        NotesViewController.create(with: makeNotesViewModel(actions: actions), storyBoardName: NotesDIContainer.storyBoard)
    }
    
    func makeNotesViewModel(actions: NotesViewModelActions) -> NotesViewModel{
        DefaultNotesViewModel(actions: actions)
    }
    
    func makeNotesUseCases() -> NotesUseCases{
        DefaultNotesUseCases(notesRepository: makeNotesRepository())
    }
    
    func makeNotesRepository() -> NotesRepository{
        DefaultNotesRepository()
    }
   
    //TODO: - Notes Edit
    
    func makeNotesEditViewController(actions: NotesEditViewModelActions) -> AddEditNotesViewController {
        AddEditNotesViewController.create(with: makeNotesEditViewModel(actions: actions), storyBoardName: NotesDIContainer.storyBoard)
    }
    
    
    func makeNotesEditViewModel(actions: NotesEditViewModelActions) -> NotesEditViewModel{
        DefaultNotesEditViewModel.init(actions: actions)
        
    }
    
    
}
