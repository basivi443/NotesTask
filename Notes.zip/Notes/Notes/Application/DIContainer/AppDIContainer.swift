//
//  AppDIContainer.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation

protocol SceneDIContainer{
    static var storyBoard: String { get }
}

 class AppDIContainer{
    
   
    // MARK: - DIContainers of scenes
    
    func makeNotesDIContainer() -> NotesDIContainer{
         NotesDIContainer.init()
    }
}
