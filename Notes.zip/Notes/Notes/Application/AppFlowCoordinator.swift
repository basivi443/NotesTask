//
//  AppFlowCoordinator.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation
import UIKit
protocol AppFlowCoordinator{
    func start()
  
}

 class DefaultAppFlowCoordinator: AppFlowCoordinator{
 
    var navigationController: UINavigationController
    private let appDIContainer: AppDIContainer
    var appDelegate: AppDelegate? {
        return UIApplication.shared.delegate as? AppDelegate
    }
    
    var appWindow: UIWindow? {
        return self.appDelegate?.window
    }
    
    init(navigationController: UINavigationController,
         appDIContainer: AppDIContainer) {
        self.navigationController = navigationController
        self.appDIContainer = appDIContainer
    }

    func start() {
        
        showNotesFlow()
        
    }
 
    func showNotesFlow(){
        let navVC = UINavigationController.init()
        let notesDIContainer = appDIContainer.makeNotesDIContainer()
        let flow = notesDIContainer.makeNotesFlowCoordinator(navigationController: navVC, flowCoordinator: self)
        appWindow?.rootViewController = navVC
        flow.start()
    }
}
