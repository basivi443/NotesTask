//
//  DefaultNotesRepository.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation
 class DefaultNotesRepository {
    
  
    
}

extension DefaultNotesRepository: NotesRepository {
   
    
}
