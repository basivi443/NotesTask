//
//  NotesModel.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation

struct NotesData{
    var title    : String?
    var subtitle : String?
    var date     : String?
    var id: String
    
    init(title: String, subtitle: String, date: String, id: String) {
        self.title = title
        self.subtitle = subtitle
        self.date = date
        self.id = id
    }
    
}
