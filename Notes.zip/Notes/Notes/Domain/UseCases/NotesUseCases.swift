//
//  NotesUseCases.swift
//  Notes
//
//  Created by Basivi Reddy - 2505 on 12/09/22.
//

import Foundation
protocol NotesUseCases {
 
}

 class DefaultNotesUseCases: NotesUseCases {
    
    private let notesRepository: NotesRepository
    
    init(notesRepository: NotesRepository) {
        self.notesRepository = notesRepository
    }
    
 
}
